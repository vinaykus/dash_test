import os
import datetime
import pandas as pd
import numpy as np
from src import DATA_PATH
from src import SERVER_PATH
import glob 
path = DATA_PATH
  
# csv files in the path
files = glob.glob(path + "/*.csv")
  
def get_data():
    df = pd.DataFrame()
    #files = [f for f in os.listdir(DATA_PATH)]
    for f in files:
        filename, ext = os.path.splitext(f)
        if ext == '.csv':
            read = pd.read_csv(f, usecols=[0,3])
            df = df.append(read, ignore_index=True)
    df.rename(columns = {'Duration in ms':'Duration'}, inplace = True)
    return df

def raw_data():
    df = pd.DataFrame()
    #files = [f for f in os.listdir(DATA_PATH)]
    for f in files:
        filename, ext = os.path.splitext(f)
        if ext == '.csv':
            read = pd.read_csv(f)
            df = df.append(read, ignore_index=True)
    df.rename(columns = {'Duration in ms':'Duration'}, inplace = True)
    return df