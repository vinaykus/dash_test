"""Analytics Page"""
from dash_html_components import H1, Div, Hr, P
import dash_bootstrap_components as dbc

from src.charts import create_component



def create_analylics_div() -> Div:
    """Function to create analytics div"""
    return Div(className="w-100 py-2 px-3 m-0", children=[
        dbc.Row([
            create_component("div-analytics-donut", "Execution Report", "v"),
            create_component("div-analytics-hist", "Category Wise Distribution", "v"),
            create_component("table-analytics", "Test Execution ","l"),


        ])
    ], **{"data-spy": "scroll", "data-target": "#side-bar", "data-offset": "0"})


def create_analytics_page() -> Div:
    """Function to create the analytics page"""
    return Div([
        dbc.Row(className="fluid-element flex-column-reverse flex-md-row", children=[
            dbc.Col(create_analylics_div(), xs=12, md=9, lg=12, className="p-0"),
        ], style={"margin-bottom": "-2rem", "background-color": "whitesmoke"})
    ])
