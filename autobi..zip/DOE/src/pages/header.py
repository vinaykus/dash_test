"""Shared elements among all pages, e.g. header"""
import os
import base64
from dash_html_components import Div, H1, Img, Span, Button
from dash_bootstrap_components import Row, Col

from src import ASSETS_PATH
from src.utils import read_config


def create_header() -> Div:
    """Return header in ST style"""
    # Encode image and get tool name from config
    path = os.path.join(ASSETS_PATH, "imgs", "st.png")
    encoded_image = base64.b64encode(open(path, "rb").read())
    image_src = "data:image/png;base64,{}".format(encoded_image.decode())
    tool_name = read_config("server.json")["TOOL_NAME"]

    # Return header layout (Username added in callback)
    return Row(
        id="header", className="align-items-center h-100",
        children=[
            Col(Img(src=image_src, id="link-"), xs=2),
            Col(H1(tool_name, id="h1-title"), xs=10, sm=7, lg=8)
        ])
