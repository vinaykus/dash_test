"""Functions to create statistics"""
import pandas as pd
from dash_html_components import Div, H4, H6
from dash_bootstrap_components import Col, Row
from .data import get_data

def get_stats(name: str, color: str) -> Div:
    """Get number div"""
    df = get_data()
    print(df)
    if name == "Total Pass":
        h4_id = df["Status"].count()
    elif name == "Duration":
        h4_id = round(df["Duration"].sum()/60000,2)
    else:
        h4_id = len(pd.concat([df["Status"], df["Duration"]]).drop_duplicates())
    return Div(
        id="",
        children=[
            H4(
                h4_id,
                className="m-0 py-2 text-white",
                style={"background-color": color},
            ),
        ],
    )


def create_stats_div(name: str, color: str) -> Col:
    """Create statistics div similar to wingxlive"""
    return Col(
        Div([H6(name, className="m-0 py-3", style={"background-color": "whitesmoke"}),
             get_stats(name, color)
             ],
            className="text-center my-2",
            style={"outline": "1px solid #6c757d"},
            ),
        xs=6,
        sm=4,
    )


def create_stats() -> Row:
    """Create global statistics for data"""
    return Row(
        [
            create_stats_div("Total Pass", "#00498f"),
            create_stats_div("Total Minutes", "#007305"),
            create_stats_div("Total Cases", "#0592a2"),
        ],
        className="justify-content-center",
    )
