"""Functions to create plots for analytics page"""
from typing import Dict
from dash_html_components import Div
from dash_core_components import Graph
from src.pages import get_data, raw_data

from src.charts import create_donut, barplot, create_table


def create_plot_donut(data: Dict) -> Div:
    """ """
    df= get_data()
    print(df.head())
    df1 = df.groupby(['Status'])['Duration'].count().reset_index().rename(columns={'Duration': 'count'})
    x =  df1['Status'].unique().tolist()
    list = df1['count'].to_list()
    return create_donut( x, list)

def create_plot_histogram(data: Dict) -> Div:
    """ """
    df= get_data()
    print(df.head())
    df1 = df.groupby(['Status'])['Duration'].count().reset_index().rename(columns={'Duration': 'count'})
    x =  df1['Status'].unique().tolist()
    list = df1['count'].to_list()
    return barplot(df1, "create_plot_bar", x, list)

def create_data_table(data: Dict) -> Div:
    """Create data table"""
    df = raw_data()
    return create_table(df, "table-analytics", styling={"filter_action": "none"})



