"""Callbacks to create main plot"""
from dash import Dash
from dash.dependencies import Input, Output, State
from .plots import (create_plot_donut, create_plot_histogram, create_data_table)


def create_analytics_callback(dash: Dash) -> None:
    # Charts, tables etc.
    pairs = [
        ("div-analytics-donut",create_plot_donut),
        ("div-analytics-hist",create_plot_histogram),
        ("table-analytics",create_data_table)


        
    ]
    for id_, func in pairs:
        dash.callback(
            Output(id_, "children"),
            [Input("store-analytics", "data")]
        )(func)
