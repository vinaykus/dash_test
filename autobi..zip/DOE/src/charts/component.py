"""Function to create component in analytics or coverage pages"""
import dash_bootstrap_components as dbc
from dash_html_components import Div, H6
from dash_core_components import Loading


def create_component(id_: str, title: str, size: str = "s") -> dbc.Col:
    """Function to create a component of fixed height, white background and title"""
    column_params = {
        "s": {"xs": 12, "md": 6, "lg": 4},
        "m": {"xs": 12, "md": 12, "lg": 8},
        "l": {"xs": 12},
        "v": {"lg": 6},
        "d": {"lg": 4},
    }[size]
    return dbc.Col(
        Div(className="h-100 p-3 analytics-component", children=[
            H6(title, className="w-100 pl-3 mb-3", style={ 'backgroundColor': '#52616b','height':"1.5rem",'color':'white' }),
            Loading(Div(id=id_, style={"min-height": "10rem"}),
                    className="dash-airplane-spinner")
        ], style={"text-align": "center", },),
        **column_params, style={"min-height": "15rem"}, className="my-3")

