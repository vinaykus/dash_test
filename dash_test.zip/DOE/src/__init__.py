import os

SERVER_PATH = os.path.dirname(os.path.abspath(__file__))
PROJECT_PATH = os.path.abspath(os.path.join(SERVER_PATH, os.pardir))

DATA_PATH = os.path.join(PROJECT_PATH, "data")
CONFIGS_PATH = os.path.join(DATA_PATH, "configs")
ASSETS_PATH = os.path.join(SERVER_PATH,  "assets")