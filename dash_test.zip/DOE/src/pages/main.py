"""Analytics Page"""
from dash_html_components import H1, Div, Hr, P
import dash_bootstrap_components as dbc

from src.charts import create_component, create_analytics_filter_div



def create_analylics_div() -> Div:
    """Function to create analytics div"""
    return Div(className="w-100 py-2 px-3 m-0", children=[
        dbc.Row([
            create_component("div-analytics-pie1", "Data Integrity", "d"),
            create_component("div-analytics-pie2", "Reliable Infrastructure", "d"),
            create_component("div-analytics-pie3", "Robust Process", "d"),
            create_component("div-analytics-pie4", "Strong Capabilities", "l"),
            create_component("div-analytics-pie5", "Data Center", "d"),
            create_component("div-analytics-pie6", "Digital Cell", "d"),
            create_component("div-analytics-pie7", "EHM Brav", "d"),

            # create_component("div-analytics-bar", "2020 Weekly Count","v"),
            # create_component("div-analytics-fly", "Total Flying Hours","v"),
            # create_component("div-analytics-model", "Model Wise Distribution","v"),
            # create_component("div-analytics-transit", "Country Transit", "v"),
            # #create_component("div-transit-table", "TOP 30 Transit", "l"),
            # create_component("div-transitper-table", "TOP 30 Transit(%)", "l"),
            # #create_component("div-analytics-table", "Raw Data", "l"),
            # #create_component("div-continent-donut","Continent-Transit","s"),
            # create_component("div-analytics-map", "TOP 50 Airports", "m"),
        ])
    ], **{"data-spy": "scroll", "data-target": "#side-bar", "data-offset": "0"})


def create_analytics_page() -> Div:
    """Function to create the analytics page"""
    return Div([
        dbc.Row(className="fluid-element flex-column-reverse flex-md-row", children=[
            dbc.Col(create_analylics_div(), xs=12, md=9, lg=12, className="p-0"),
            #dbc.Col(create_analytics_filter_div(), xs=12, md=3, lg=2, className="p-0"),
        ], style={"margin-bottom": "-2rem", "background-color": "whitesmoke"})
    ])
