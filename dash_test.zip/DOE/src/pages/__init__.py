from dash_html_components import Div

from .header import create_header
from .stats import  create_stats
from .main import create_analytics_page
from .data import  get_data, top_transit, top_perTransit
from .login import create_login_page


def create_page(name: str) -> Div:
    """Returns elements which are displayed in main-content"""
    return {
        "login": create_login_page,
    }.get(name, create_login_page)()