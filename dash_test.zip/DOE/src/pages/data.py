import os
import datetime
import pandas as pd
import numpy as np
from src import DATA_PATH


def get_data():
    path = os.path.join(DATA_PATH, "fa-data.csv")
    df = pd.read_csv(path)


    df['TRANSIT'] = np.where(df['OCOUNTRY'] < df['DCOUNTRY'], \
                             df['OCOUNTRY'].astype('str') + "-" + df['DCOUNTRY'].astype('str'), \
                             df['DCOUNTRY'].astype('str') + "-" + df['OCOUNTRY'].astype('str'))

    df['CONTINENT'] = np.where(df['OCONTINENT'] < df['DCONTINENT'], \
                               df['OCONTINENT'].astype('str') + "-" + df['DCONTINENT'].astype('str'), \
                               df['DCONTINENT'].astype('str') + "-" + df['OCONTINENT'].astype('str'))

    return df


df1 = get_data().pivot_table(index='TRANSIT', columns='WEEK', values='REG', aggfunc='count', margins=True,
                             margins_name='Total', fill_value=0, dropna=True)\
    .reset_index().sort_values(by=['Total'], ascending=False).head(30)

df1 = df1[df1['TRANSIT'] != 'Total']
#del df1.columns.name

top_transit = df1.copy()

for i in np.arange(1, 17):
    df1[i] = round(df1[i] / df1[i].sum() * 100, 2)

df1['Total'] = round(df1['Total'] / df1['Total'].sum() * 100, 2)

top_perTransit = df1
