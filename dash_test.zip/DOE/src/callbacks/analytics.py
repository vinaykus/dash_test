"""Callbacks to create main plot"""
from dash import Dash
from dash.dependencies import Input, Output, State
from .plots import (create_plot_model, create_plot_bar,create_plot_flyingbar,create_verticlebar, create_map_graph,create_continent_donut,  create_donut1,
    create_donut2,create_donut3,create_donut4,create_donut5,create_donut6,create_donut7)
from .tables import create_data_table, create_transit_table,create_trnasitper_table



def create_analytics_callback(dash: Dash) -> None:
    # Charts, tables etc.
    pairs = [
        ("div-analytics-bar",create_plot_bar),
        ("div-analytics-fly",create_plot_flyingbar),
        ("div-analytics-model", create_plot_model),
        ("div-analytics-transit",create_verticlebar),
        ("div-analytics-table", create_data_table),
        ("div-transit-table", create_transit_table),
        ("div-transitper-table",create_trnasitper_table),
        ("div-analytics-map",create_map_graph),
        ("div-continent-donut",create_continent_donut),
        
        ("div-analytics-pie1",create_donut7),
        ("div-analytics-pie2",create_donut1),
        ("div-analytics-pie3",create_donut2),
        ("div-analytics-pie4",create_donut3),
        ("div-analytics-pie5",create_donut4),
        ("div-analytics-pie6",create_donut5),
        ("div-analytics-pie7",create_donut6)



    ]
    for id_, func in pairs:
        dash.callback(
            Output(id_, "children"),
            [Input("store-analytics", "data")]
        )(func)
