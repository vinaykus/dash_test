"""Functions to create tables for analytics page"""
from typing import Dict, List
from dash_html_components import Div
from dash_bootstrap_components import Col, Row
from src.charts import create_table, boxplot, transit_table
from src.pages import get_data,top_transit,top_perTransit


def create_data_table(data: Dict) -> Div:
    """Create data table"""
    df = get_data()
    return create_table(df, "table-analytics", styling={"filter_action": "none"})

def create_transit_table(data:Dict) ->Div:
    df = top_transit
    return  transit_table(df,"div-transit-table",styling={"filter_action": "none"})

def create_trnasitper_table(data:Dict) -> Div:
    df = top_perTransit
    return transit_table(df,"create_trnasitper_table",styling={"filter_action": "none"})