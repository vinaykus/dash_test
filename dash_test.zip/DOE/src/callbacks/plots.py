"""Functions to create plots for analytics page"""
from typing import Dict
from dash_html_components import Div
from dash_core_components import Graph
from src.pages import get_data

from src.charts import lineplot, barplot, barplot1, verticlebar, create_map,create_donut

df = get_data()


def create_plot_bar(data: Dict) -> Div:
    """ Create Bar plot for weekly hours"""
    df1 = df.groupby(['WEEK','YEAR'])['REG'].count().reset_index().rename(columns={'REG': 'count'})
    x = ('Week ' + df1['WEEK'].astype(str)+','+df1['YEAR'].astype(str)).to_list()
    list = df1['count'].to_list()
    return barplot(df1, "create_plot_bar", x, list)


def create_plot_flyingbar(data: Dict) -> Div:
    """ Create Bar plot for weekly hours"""
    df1 = round(df.groupby(['WEEK','YEAR'])['DURATION'].agg('sum').reset_index(), 2)
    x = ('Week ' + df1['WEEK'].astype(str)+','+df1['YEAR'].astype(str)).to_list()
    l = df1['DURATION'].to_list()
    return barplot1(df1, "create_plot_flyingbar", x, l)


def create_verticlebar(data: Dict) -> Div:
    """ Create Bar plot for weekly hours"""
    df1 = df.groupby(['TRANSIT'])['REG'].count().reset_index().rename(columns={'REG': 'count'}).sort_values('count',
                                                                                                          ascending=False).head(15)
    x = df1['TRANSIT'].to_list()
    l1 = df1['count'].to_list()
    return verticlebar(df1, "create_verticlebar", x, l1)


def create_plot_model(data: Dict) -> Div:
    """Create line plot for Model distribution"""
    df1 = df.groupby(['AIRCRAFTTYPE', 'WEEK','YEAR'])['DURATION'].agg('sum').reset_index()
    list = df1.AIRCRAFTTYPE.unique()
    x = ('Week ' + df1['WEEK'].astype(str)+','+df1['YEAR'].astype(str)).to_list()
    return lineplot(df1, "line_id", x, list, True)


def create_line_graph(data: int) -> Div:
    """ Create line graph"""
    df1 = df.groupby(['WEEK','YEAR'])['REG'].count().reset_index().rename(columns={'REG': 'count'})
    x = ('Week ' + df1['WEEK'].astype(str)+','+df1['YEAR'].astype(str)).to_list()
    l = df1['count'].to_list()
    return lineplot(df1, "line_id1", x, l, True)

def create_map_graph(data:Dict) -> Div:
    df2 = df.groupby(
        ['OAIRPORT', 'OLONGITUDE', 'OLATITUDE', 'OCOUNTRY', 'DAIRPORT', 'DLONGITUDE', 'DLATITUDE', 'DCOUNTRY',
         'TRANSIT'])['REG'].count().reset_index().rename(columns={'REG': 'count'}).sort_values('count',
                                                                                               ascending=False).reset_index()
    df2= df2.head(50)
    return create_map(df2)

def create_continent_donut(data:Dict) -> Div:
    df1 = df.groupby(['CONTINENT'])['REG'].count().reset_index().rename(columns={'REG': 'count'}).sort_values('count',
                                                                                                        ascending=False)
    labels = df1.CONTINENT.to_list()
    values = df1['count'].to_list()
    return create_donut(labels,values)

def create_donut1(data:Dict) -> Div:
    labels = ['IT','SE','COGNOS']
    values = [10,20,30]
    return create_donut(labels,values)

def create_donut2(data:Dict) -> Div:
    labels = ['IT','SE','COGNOS']
    values = [10,20,30]
    return create_donut(labels,values)

def create_donut3(data:Dict) -> Div:
    labels = ['IT','SE','COGNOS']
    values = [10,20,30]
    return create_donut(labels,values)

def create_donut4(data:Dict) -> Div:
    labels = ['IT','SE','COGNOS']
    values = [10,20,30]
    return create_donut(labels,values)

def create_donut5(data:Dict) -> Div:
    labels = ['IT','SE','COGNOS']
    values = [10,20,30]
    return create_donut(labels,values)
    
def create_donut6(data:Dict) -> Div:
    labels = ['IT','SE','COGNOS']
    values = [10,20,30]
    return create_donut(labels,values)

def create_donut7(data:Dict) -> Div:
    labels = ['IT','SE','COGNOS']
    values = [33,33,33]
    return create_donut(labels,values)