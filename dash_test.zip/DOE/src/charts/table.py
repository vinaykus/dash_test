"""Function for creating a data table"""
import pandas as pd
from dash_table import DataTable
from .table_styling import get_shared_styles


def create_table(df: pd.DataFrame, t_id: str, styling: None
                 ) -> DataTable:
    """Create and return data table"""
    complete_styling = get_shared_styles(df)
    if styling is not None:
        complete_styling.update(styling)

    df_new = df.drop(columns=["ID", "YEAR", "MONTH", "WEEK", "TRANSIT"])
    return DataTable(
        id=t_id, data=df_new.to_dict("records"),
        columns=[{"name": col, "id": col} for col in df_new.columns],
        fixed_rows={'headers': True, 'data': 0},
        **complete_styling
    )


def transit_table(df: pd.DataFrame, t_id: str, styling: None
                  ) -> DataTable:
    """Create and return data table"""
    complete_styling = get_shared_styles(df)
    if styling is not None:
        complete_styling.update(styling)

    df_new = df
    return DataTable(
        id=t_id, data=df_new.to_dict("records"),
        columns=[{"name": col, "id": col} for col in df_new.columns],
        **complete_styling
    )
