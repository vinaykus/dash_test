"""Functions to create date-related elements"""
from typing import Optional
from datetime import datetime
from dash_core_components import DatePickerRange


def create_datepicker(id_: str,
                      start_date: Optional[datetime] = None,
                      end_date: Optional[datetime] = None,
                      with_portal: bool = False) -> DatePickerRange:
    """Create generic datepicker"""
    start = datetime(2018, 1, 1) if start_date is None else start_date
    end = datetime(2018, 12, 31) if end_date is None else end_date
    return DatePickerRange(
        id=id_,
        start_date=start,
        end_date=end,
        display_format='YYYY-MM-DD',
        with_portal=with_portal
    )
