"""Functions to create plots"""
from typing import List, Dict, Any
import numpy as np
import pandas as pd
from dash_core_components import Graph
import plotly.graph_objs as go


def create_donut(labels: List[str], values: List[int]) -> Graph:
    """Create a donut plot"""
    return Graph(style={"height": "26rem"}, figure={
        "data": [go.Pie(labels=labels, values=values, textinfo='label', hole=.2)],
        "layout": go.Layout(
            margin={"l": 60, "r": 60},
            showlegend=False,
            paper_bgcolor="rgb(255,255,255,0)"
        )
    }, config={"displayModeBar": False})


def violin(df: pd.DataFrame, graph_id: str, name: str) -> Graph:
    """Create and return a bar plot"""
    return Graph(id=graph_id, figure=go.Figure(
        data=[go.Violin(y=df[name], name=name)],
        layout=go.Layout(
            showlegend=False,
            legend=go.layout.Legend(x=0, y=1.0),
            margin=go.layout.Margin(l=40, r=0, t=40, b=30)  # noqa (l is an ambigous name)
        )
    ))


def lineplot(df: pd.DataFrame, graph_id: str, x: str, names: List[str], showlegend: bool = False
             ) -> Graph:
    """Create and return a bar plot"""
    return Graph(id=graph_id, figure=go.Figure(
        data=[go.Scatter(x=x, y=df[df['AIRCRAFTTYPE'] == i]['DURATION'], mode="lines+markers", marker=dict(size=10), name=i) for i
              in names],
        layout=go.Layout(
            showlegend=showlegend,
            autosize=True,
            xaxis_tickangle=-45,
            legend=go.layout.Legend(x=0.9, y=1.0),
            margin=go.layout.Margin(l=40, r=10, t=10, b=30)  # noqa (l is an ambigous name)
        )
    ), config={"displayModeBar": False})


def boxplot(df: pd.DataFrame, graph_id: str, names: List[str], yaxis_type: str = "linear") -> Graph:
    """Create and return a boxplot"""
    return Graph(id=graph_id, figure=go.Figure(
        data=[go.Box(y=df[name], name=name, jitter=0.1) for name in names],
        layout=go.Layout(
            showlegend=False,
            yaxis_type=yaxis_type,
            legend=go.layout.Legend(x=1.0, y=1.0),
            margin=go.layout.Margin(l=40, r=0, t=40, b=30)  # noqa (l is an ambigous name)
        )
    ))


def histogram(df: pd.DataFrame, graph_id: str, names: List[str]) -> Graph:
    """Create and return a boxplot"""
    return Graph(id=graph_id, figure=go.Figure(
        data=[go.Histogram(x=df[name], name=name, opacity=0.8) for name in names],
        layout=go.Layout(
            barmode='overlay',
            legend=go.layout.Legend(x=0, y=1.0),
            margin=go.layout.Margin(l=40, r=0, t=40, b=30)  # noqa (l is an ambigous name)
        )
    ))


def barplot(df: pd.DataFrame, graph_id: str, x: List[str], names: List[str]) -> Graph:
    """Create and return a barplot"""
    return Graph(id=graph_id, figure=go.Figure(
        data=[go.Bar(x=x, y=names, marker_color="#035aa6", text=names, textposition='outside')],
        layout=go.Layout(
            xaxis_title="Weeks",
            yaxis_title="Flight Count",
            xaxis_tickangle=-45,
            margin=go.layout.Margin(l=40, r=0, t=40, b=30)  # noqa (l is an ambigous name)
        )
    ), config={"displayModeBar": False})


def barplot1(df: pd.DataFrame, graph_id: str, x: List[str], names: List[str]) -> Graph:
    """Create and return a barplot"""
    return Graph(id=graph_id, figure=go.Figure(
        data=[go.Bar(x=x, y=names, marker_color="#035aa6", text=names, textposition='auto')],
        layout=go.Layout(
            xaxis_title="Weeks",
            yaxis_title="Flying Hours",
            xaxis_tickangle=-45,
            margin=go.layout.Margin(l=40, r=0, t=40, b=30)  # noqa (l is an ambigous name)
        )
    ), config={"displayModeBar": False})


def verticlebar(df: pd.DataFrame, graph_id: str, x: List[str], names: List[str]) -> Graph:
    """Create and return a barplot"""
    return Graph(id=graph_id, figure=go.Figure(
        data=[go.Bar(x=names, y=x, marker_color="#035aa6",text=names, textposition='auto', orientation='h')],
        layout=go.Layout(
            xaxis_title="Transit Count",
            yaxis_title="Transit Country",
            margin=go.layout.Margin(l=40, r=0, t=40, b=30)  # noqa (l is an ambigous name)
        )
    ), config={"displayModeBar": False})


def scatter(df: pd.DataFrame, graph_id: str, names: List[str], use_gl: bool = False) -> Graph:
    """Create and return a bar plot"""
    scatter_plot = go.Scatter
    marker: Dict = {}
    if use_gl:
        scatter_plot = go.Scattergl
        sizes = df.groupby(names[:2])[names[2]].count().apply(np.log2) * 2 + 10
        sizes = sizes.reset_index().rename(columns={names[2]: "Size"})
        df = pd.merge(df, sizes, on=names[:2])
        df = df.drop_duplicates(subset=names[:2])
        df[names[3]] = df["ORIGIN"] + " --> " + df["DESTINATION"] + " (" + df["DATE"] + ")"
        marker = dict(size=df["Size"])

    def text(name: str) -> Any:
        """Get tooltip texts"""
        if use_gl:
            counts = (2 ** ((df["Size"] - 5) / 2)).astype(int).astype(str)
            return "Counts: " + counts + "; " + df.loc[df[names[2]] == name, names[3]].astype(str)
        return names[2] + ": " + df.loc[df[names[2]] == name, names[3]].astype(str)

    return Graph(id=graph_id, figure=go.Figure(
        data=[
            scatter_plot(
                x=df.loc[df[names[2]] == name, names[0]],
                y=df.loc[df[names[2]] == name, names[1]],
                mode='markers',
                marker=marker,
                name=str(name),
                text=text(name)
            ) for name in df[names[2]].unique()
        ],
        layout=go.Layout(
            legend=go.layout.Legend(x=0, y=1.0),
            xaxis_title=names[0],
            yaxis_title=names[1],
            clickmode="event+select",
            margin=go.layout.Margin(l=40, r=0, t=40, b=30)  # noqa (l is an ambigous name)
        )
    ))



def bar_stacked(df: pd.DataFrame, graph_id: str) -> Graph:
    """Create a stacked bar plot"""
    columns = ["Wingx", "Flightaware", "Rolls Royce"]
    columns += [c + " (Total)" for c in ["WX", "FA", "RR"]]

    return Graph(id=graph_id, figure=go.Figure(
        data=[
            go.Bar(x=columns, y=df.iloc[i], name="Additional" if i == 1 else "Shared")
            for i in [0, 1]
        ],
        layout=go.Layout(
            barmode="stack",
            showlegend=False,
            xaxis={"range": [-1, 6]},
            margin=go.layout.Margin(l=40, r=0, t=40, b=30)  # noqa (l is an ambigous name)
        )
    ))


def create_map(df: pd.DataFrame) -> Graph:

    fig = go.Figure()
    for i in range(len(df)):
        fig.add_trace(
            go.Scattermapbox(
                lon=[df['OLONGITUDE'][i], df['DLONGITUDE'][i]],
                lat=[df['OLATITUDE'][i], df['DLATITUDE'][i]],
                mode='markers+lines',
                textposition="bottom right",
                showlegend=True,
                name=df['TRANSIT'][i],
                text=[df['OAIRPORT'][i], df['DAIRPORT'][i]]

            )
        )
    fig.update_layout(
        margin={'l': 0, 't': 0, 'b': 0, 'r': 0},
        showlegend=False,
        mapbox={
            'center': {'lon': 0, 'lat': 0},
            'style': "stamen-terrain",
            'zoom': 1}
    )
    fig.update_geos(projection_type="natural earth")

    return Graph(id="world-map", figure=fig, config={"displayModeBar": False})
