"""Functions for creating repetitive styles"""
from typing import List, Dict, Any
import pandas as pd


def get_align_map() -> Dict[str, List[str]]:
    """Mapping of columns to alignment, default is right"""
    return {
        "left": ["name", "date", "created_at", "status", "comment"],
        "center": [],
        "right": []
    }


def get_aligned() -> List[Dict]:
    """Return list of style objects for columns"""
    return [{"if": {"column_id": c}, "textAlign": a}
            for a, cols in get_align_map().items() for c in cols]


def get_even_odd_coloring() -> List[Dict]:
    """Return styling for even-odd coloring"""
    mapping = {"odd": "#dbdbdb", "even": "white"}
    return [{"if": {"row_index": k}, "backgroundColor": v} for k, v in mapping.items()]


def get_shared_styles(df: pd.DataFrame) -> Any:
    """Return styles for header and cells"""
    max_height = "{:d}rem".format(min(30, int(4 + 2 * len(df.index))))

    return {
        "sort_action": "native",
        "sort_mode": "multi",
        "page_action": "native",
        "filter_action": "native",
        "style_cell_conditional": get_aligned() + get_even_odd_coloring(),
        "style_table": {"overflowX": "auto", "maxWidth": "100%", "maxHeight": max_height},
        "style_cell": {"padding": "0.5rem 0.5rem", "line-height": "100%", "font-size": "11px",'textAlign': 'center'},
        "style_header": {"fontWeight": "bold", "text-align": "center", "backgroundColor": "#a4c5c6"},
    }
