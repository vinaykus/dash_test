"""Utility functions for the filter div of the analytics page"""
from typing import List, Tuple, Any, Optional, Union
from datetime import datetime
from flask import request
from dash_html_components import Div, H4
from dash_core_components import Dropdown
import dash_bootstrap_components as dbc


from src.charts import create_datepicker


def dropdown(id_: str, placeholder: str = "", multi: bool = True, value: Optional[str] = ""
             ) -> Dropdown:
    """Create empty dropdown"""
    value_parsed: Union[List[str], str, None] = value.split(",") if multi and value else value
    return Dropdown(id=id_, options={}, multi=multi, placeholder=placeholder, value=value_parsed)


def create_analytics_filter_div() -> Div:
    """Function to create analytics filter div"""
    return Div(id="side-bar", className="w-100 p-2 m-0 side-bar sticky-top", children=[
        H4("Filter options", className="my-4 w-100 text-center"),
        dbc.Row([
            dbc.Col(dbc.FormGroup(
                [dbc.Label(label, html_for=id_, className="w-100 ml-2"), element]
            ), md=12, xs=(12 if label == "Period" else 6))
            for label, id_, element in get_filter()
        ], form=True)
    ])


def get_filter() -> List[Tuple[str, str, Any]]:
    """Return list of filters"""
    # Get url parameters which can initialize filter
    # Get default values
    template = "%Y-%m-%d"
    today = datetime.utcnow().strftime(template)
    first_day = "2020-01-01"

    # Read from filters
    start = datetime.strptime(first_day, template)
    end = datetime.strptime( today, template)

    # Create elements
    elements = [
        create_datepicker("datepicker-time", start, end, True),

    ]
    return [
        ("Period", "datepicker-time", elements[0]),

    ]
