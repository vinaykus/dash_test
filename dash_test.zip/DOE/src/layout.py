"""Definition of main layout"""
from typing import Any
from flask import has_request_context
from dash_html_components import Div, Link
from dash_core_components import Location, Store
from dash_bootstrap_components import Container

from src.pages import create_header,create_stats,create_analytics_page,create_page


def serve_layout(debug: bool = False) -> Any:
    """Function for serving layout - important for updates on page reload"""
    main_content = Div(id="main-content")
    if debug and not has_request_context():
        main_content = Div(id="main-content", children=[
            #create_stats(),
            create_analytics_page(),
            #create_page("login"),

        ])

    return Container(id="main", children=[
        Location(id="url", refresh=False),
        Link(rel="shortcut icon", href="favicon.ico"),
        Store(id="store-data-general", storage_type="session"),
        Store(id="store-data-processes", storage_type="session"),
        Store(id="store-analytics", storage_type="session"),
        create_header(),
        main_content
    ])
