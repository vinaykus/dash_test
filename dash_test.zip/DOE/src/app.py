"""Flask Server"""
from flask import Flask
from src.utils import read_config,init_logger



def create_app(mode: str) -> Flask:
    """Initialize"""
    # Init app
    app = Flask(__name__)
    config = read_config("server.json")
    app.secret_key = config["SECRET_KEY"]
    app.config["SERVER_CONFIG"] = config[mode]
    app.app_context().push()

    # Init db and logger
    init_logger(mode)
    return app
