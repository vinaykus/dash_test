"""Dashboard for data exploration"""
import os
from flask import Flask
from dash import Dash
from dash_bootstrap_components import themes

from src.utils import read_config
from src import SERVER_PATH
from src.layout import serve_layout
from src.callbacks import create_analytics_callback,create_login_callback


def create_dashboard(app: Flask) -> Dash:
    """Create the dashboard"""
    debug = app.config["SERVER_CONFIG"]["DEBUG"]
    base_link = app.config["SERVER_CONFIG"]["BASE_LINK"]

    dash = Dash(__name__, server=app,
                assets_folder=os.path.join(SERVER_PATH, "assets"),
                external_scripts=["https://code.jquery.com/jquery-3.3.1.min.js"],
                external_stylesheets=[
                    themes.BOOTSTRAP,
                    "https://use.fontawesome.com/releases/v5.8.2/css/all.css"
                ],
                suppress_callback_exceptions=~debug,
                requests_pathname_prefix=base_link + "/",
                meta_tags=[{
                    "name": "viewport",
                    "content": "width=device-width, initial-scale=1"
                }])

    dash.title = read_config("server.json")["TOOL_NAME"]
    dash.layout = serve_layout(debug)
    #create_login_callback(dash)
    create_analytics_callback(dash)

    dash.enable_dev_tools(debug, dev_tools_props_check=False)
    return dash
