$(document).ready(function() {
  if (!window.dash_clientside) {
    window.dash_clientside = {};
  }
  window.dash_clientside.clientside = {
    // LOGIN
    update_login_link: function(data, email, password) {
      // Updates login link with email/password in case of ldap
      loginLink = "/login";
      if (email && password) {
        loginLink += "?email=" + email + "&password=" + password;
      }
      return data["BASE_LINK"] + loginLink;
    },
    validate_email: function(email) {
      // Validates email in login form
      if (email) {
        isValid = email.toLowerCase().endsWith("@rolls-royce.com");
        return [isValid, !isValid];
      }
      return [false, false];
    }
  };
});
