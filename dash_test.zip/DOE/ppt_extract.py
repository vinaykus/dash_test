import pandas as pd
from pptx import Presentation


def tab1(ppt):
    tb1 = ppt.slides[0].shapes[2].table
    rows = len(tb1.rows)
    cols = len(tb1.columns)
    columns_names = []
    data = []
    for i in range(cols):
        columns_names.append(tb1.cell(0, i).text)

    i = 1
    while i < rows:
        data.append([tb1.cell(i, 0).text, tb1.cell(i, 1).text, tb1.cell(i, 2).text])
        i += 1
    table1 = pd.DataFrame(data, columns=columns_names)
    print(table1)
    return table1


def tab2(ppt):
    tb1 = ppt.slides[0].shapes[6].table
    rows = len(tb1.rows)
    cols = len(tb1.columns)
    columns_names = []
    data = []
    for i in range(cols):
        columns_names.append(tb1.cell(0, i).text)
    i = 1
    while i < rows:
        data.append([tb1.cell(i, 0).text, tb1.cell(i, 1).text, tb1.cell(i, 2).text, tb1.cell(i, 3).text])
        i += 1
    table2 = pd.DataFrame(data, columns=columns_names)
    print(table2)
    return table2


def tab3(ppt):
    tb1 = ppt.slides[0].shapes[7].table
    rows = len(tb1.rows)
    cols = len(tb1.columns)
    columns_names = []
    data = []
    for i in range(cols):
        columns_names.append(tb1.cell(0, i).text)
    i = 1
    while i < rows:
        data.append([tb1.cell(i, 0).text])
        i += 1
    table3 = pd.DataFrame(data, columns=columns_names)
    print(table3)
    return table3


def tab4(ppt):
    tb1 = ppt.slides[0].shapes[11].table
    rows = len(tb1.rows)
    cols = len(tb1.columns)
    columns_names = []
    data = []
    for i in range(cols):
        columns_names.append(tb1.cell(0, i).text)
    i = 1
    while i < rows:
        data.append([tb1.cell(i, 0).text])
        i += 1
    table4 = pd.DataFrame(data, columns=columns_names)
    print(table4)
    return table4


def tab5(ppt):
    tb1 = ppt.slides[0].shapes[8].table
    rows = len(tb1.rows)
    cols = len(tb1.columns)
    columns_names = []
    data = []
    for i in range(cols):
        columns_names.append(tb1.cell(0, i).text)
    i = 1
    while i < rows:
        data.append([tb1.cell(i, 0).text])
        i += 1
    table5 = pd.DataFrame(data, columns=columns_names)
    print(table5)
    return table5


def tab6(ppt):
    tb1 = ppt.slides[0].shapes[9].table
    rows = len(tb1.rows)
    cols = len(tb1.columns)
    columns_names = []
    data = []
    for i in range(cols):
        columns_names.append(tb1.cell(0, i).text)
    i = 1
    while i < rows:
        data.append([tb1.cell(i, 0).text])
        i += 1
    table6 = pd.DataFrame(data, columns=columns_names)
    print(table6)
    return table6


def other_details(ppt):
    date = ppt.slides[0].shapes[14].table.cell(0, 1).text
    ap_week = ppt.slides[0].shapes[15].table.cell(0, 1).text
    project_name = ppt.slides[0].shapes[13].table.cell(0, 1).text
    presenter_name = ppt.slides[0].shapes[16].table.cell(0, 1).text
    progress = ppt.slides[0].shapes[13].table.cell(0, 2).text
    color = []
    for i in range(1, 7):
        color.append(ppt.slides[0].shapes[2].table.cell(i, 2).fill.fore_color.rgb)
    print("Other Details: "+ date, ap_week, project_name, presenter_name, progress, color)
    return date, ap_week, project_name, presenter_name, progress, color


if __name__ == '__main__':
    ppt = Presentation('DOE-tableTemplate.pptx')
    tab1(ppt)
    tab2(ppt)
    tab3(ppt)
    tab4(ppt)
    tab5(ppt)
    tab6(ppt)
    other_details(ppt)
