import dash_core_components as dcc
import dash_html_components as html
from dash.dependencies import Input, Output

from app import app
from layouts import layout1, layout2, layout3, Base
import callbacks
import plotly.graph_objects as go

labels = ['IT','SE','Cognos','Maximo']
values = [4500, 2500, 1053, 500]

# pull is given as a fraction of the pie radius
fig = go.Figure(data=[go.Pie(labels=labels, values=values)])
app.layout = html.Div([
    dcc.Graph(
        id='basic-interactions',
        config={'editable':True},
        figure=fig
    ),
    html.Div(id='page-content'),

])



@app.callback(Output('page-content', 'children'),
              [ Input('basic-interactions', 'clickData')])
def display_page(clickData):
    if clickData['points'][0]['label'] == 'IT':        
        return Base
    elif clickData['points'][0]['label'] == 'SE':
         return layout1
    elif clickData['points'][0]['label'] == 'Cognos':
         return layout2
    elif clickData['points'][0]['label'] == 'Maximo':
         return layout3
    else:
        return '404'




if __name__ == '__main__':
    app.run_server(debug=False)