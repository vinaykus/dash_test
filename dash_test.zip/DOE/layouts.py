import dash_core_components as dcc
import dash_html_components as html
import plotly.graph_objects as go
import ppt_extract as p
from pptx import Presentation
import plotly.express as px

system=['IT', 'Maximo', 'SE','Cognos']

fig = go.Figure([go.Bar(x=system, y=[20, 14, 23])])

Base= html.Div([
    html.H3('You have selected IT region'),
    dcc.Graph(
        id='basic',
        config={'editable':True},
        figure=fig
    )

])

fig2 = go.Figure(data=[
    go.Bar(name='RRD', x=system, y=[20, 14, 23]),
    go.Bar(name='CLE', x=system, y=[12, 18, 29])
])
fig2.update_layout(barmode='group')


labels = ['Do-IT','Road Runner','HP28','Apach2']
values = [100, 200, 300, 500]

# pull is given as a fraction of the pie radius
fig3 = go.Figure(data=[go.Pie(labels=labels, values=values)])

ppt = Presentation('DOE-tableTemplate.pptx')
df1 = p.tab1(ppt)
fig4 = px.bar(df1, x="Key Milestones", y="Target",  barmode="group")

layout1 = html.Div([
    html.H3('You have selected SE region'),
    dcc.Dropdown(
        id='app-1-dropdown',
        options=[
            {'label': 'App 1 - {}'.format(i), 'value': i} for i in [
                'IT', 'SE', 'COGNOS', 'MAXIMO'
            ]
        ]
    ),
    dcc.Graph(
        id='basic1',
        config={'editable':True},
        figure=fig2
    ),

])

layout2 = html.Div([
    html.H3('You have selected Cognos region'),
    dcc.Dropdown(
        id='app-2-dropdown',
        options=[
            {'label': 'App 2 - {}'.format(i), 'value': i} for i in [
                'DO-IT', 'Road Runner', 'HP28'
            ]
        ]
    ),
    dcc.Graph(
        id='basic3',
        config={'editable':True},
        figure=fig4
    ),
])

layout3 = html.Div([
    html.H3('You have selected Maximo region'),
    dcc.Graph(
        id='basic2',
        config={'editable':True},
        figure=fig3
    ),
])