"""Script for running flask server and dashboard"""
import os
from src.app import create_app
from src.dashboard import create_dashboard

if __name__ == "__main__":
    os.environ["OAUTHLIB_INSECURE_TRANSPORT"] = "1"
    app = create_app("LOCAL")
    create_dashboard(app)
    app.run(host='127.0.0.1',port=4000,debug=True)
